#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>


/*char* esitoCheck(int* esatta,int* tentativo){
    
    char* res;
    
    int i,j;
    int k=0;//k parla con res
    
    res=(char*)malloc(sizeof(char) * 4 );
    
    for(i=0;i<4;i++){//cicla su *tentativo
    
        for(j=0;j<4;j++){//cicla su *esatta
            
            if( tentativo[i]==esatta[j] && i==j){
                res[k]='s';//numero presente e in pos esatta
                k++;
            }
            else if(tentativo[i]==esatta[j] && i!=j){
                res[k]='n';
                k++;                
            }//altrimenti res[k]='a', dove a= numero assente    
            
        }        
        
   
   
   
   /*
    * 
    * Test: int controlloNumeri(...) esito positivo:
    * --restituisce esattamente quanti numeri sono stati indovinati senza però
    * -- specificare se in pos corretta o sbagliata
    * 
    *   
    * 
    */
    
    
    
    
   
   
   
int* controlloNumeri(int *esatta,int *tentativo){
    
    int *res;
    int i,j; //j=vettore esatta & i=vettore tentativo
    
    int k=0; //indica la reale dimensione di *res;
    
    
    for(i=0;i<4;i++){//tentativo
        for(j=0;j<4;j++){//esatta
            int numAt=tentativo[i];
            if(esatta[j]==numAt){
                (k)++;
            }             
        }//fine for j
    }//fine for di i
    
    /* I 2 FOR:  restituiscono esattamente quanti numeri sono stati indovinati senza però
    *        specificare se in pos corretta o sbagliata
    * 
    */
    
    //printf("Numeri presi: %d\n",k);
    //return k;
    
    
    
    //******** QUANTITA NUMERI PRESI CORRETTI
    
    
    res=(int*)malloc(sizeof(int)* 3);
    
    
    int posCorretta=0;
    int posScorretta=0;
    int numAssenti=0;
    
    for(i=0;i<4;i++){//CICLO ESTERNO SU TENTATIVO
        for(j=0;j<4;j++){
            if(tentativo[i]==esatta[j] && j==i){//stessa posizione
               posCorretta++;
            }
            else if(tentativo[i]==esatta[j] && j!=i){
                posScorretta++;
            }           
        }//FINE CICLO INTERNO(esattaCombinazione)
    }
    
    printf("CORRETTI: %d - POS SCORRETTA: %d\n",posCorretta,posScorretta,numAssenti);
    
    
   res[0]=posCorretta;
   res[1]=posScorretta;
   
   return res; 
     
}


int getDimensionVector(int *vc){//OK
    return sizeof(vc)/sizeof(vc[0]);   
}






void main(){
    int esatta[]={1,2,3,4};
    int tent[]={1,6,3,9};
    int dim;
   
    
    int *res=controlloNumeri(esatta,tent);
    dim=getDimensionVector(res);
    printf("Dimensione array post-check: %d\n\n",dim);
    printf("ESITO CHECKING:\n");
    
    int i;
    
    for(i=0;i<dim;i++){
        
        printf("%d ",res[i]);
        
        
    }
    printf("\n");
    
    
 free(res);   
    
    
    
}