#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define false 0
#define true 1

/*
 * GENERA UNA SEQUENZA DI NUMERI CASUALI DA 1 A 9
 * E LI METTE IN UN VETTORE,(in questo caso), DI 4 ELEMENTI)
 */




void main(){
    
    int v[4];
    int i;
    int k;
      
    for(i=0;i<4;i++){
        int ok=false;
        while(!ok){
            srand(time(NULL));
            v[i]=rand()%9+1;
            ok=true;
            for(k=0;k<i;k++){
                if(v[i]==v[k])
                    ok=false;       
                
            }
       
        }
      
    }

    printf("Numeri Casuali:\n");
       for(k=0;k<4;k++)
           printf("%d ",v[k]);
    printf("\n");
 
}//FINE MAIN